# OptimicerMod (Forge 1.20.1)

Mod de cliente para subir FPS. Funciona sin configurar (objetivo 400 FPS).
Para buscar 699 FPS: en `config/optimicermod-client.toml` pon `mode = "EXTREME"` y `targetFps = 699`.

## Compilar el .jar
1. Instala JDK 17.
2. Descarga el MDK de Forge 1.20.1 (files.minecraftforge.net) y copia `gradlew`, `gradlew.bat`
   y la carpeta `gradle/` a esta carpeta. (O ejecuta `gradle wrapper --gradle-version 8.1.1`.)
3. Ejecuta `./gradlew build` (Windows: `gradlew.bat build`).
4. El jar queda en `build/libs/OptimicerMod-1.0.0.jar`. Ponlo en tu carpeta `mods`.

## Que hace
- Quita el limite de FPS y VSync al iniciar.
- Limitador propio opcional (`fpsCap`, admite mas de 260) y limite de FPS en segundo plano.
- Calidad dinamica: mide los FPS y baja/sube distancia de renderizado, particulas,
  distancia de entidades, sombras, nubes y graficos hasta acercarse a `targetFps`.
  Al salir del mundo restaura tus ajustes.

## Importante
Los FPS finales dependen de tu PC. El mod no reescribe el motor de render; para
mas rendimiento combinalo con Embeddium/Rubidium, FerriteCore y EntityCulling.
