package com.optimicer;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import org.slf4j.Logger;

/**
 * OptimicerMod - mod cliente de optimizacion para Minecraft 1.20.1 (Forge).
 * Toda la logica de cliente vive en {@link com.optimicer.client.ClientHandler}.
 */
@Mod(OptimicerMod.MOD_ID)
public class OptimicerMod {
    public static final String MOD_ID = "optimicermod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public OptimicerMod() {
        ModLoadingContext.get().registerConfig(
                ModConfig.Type.CLIENT, OptimicerConfig.SPEC, "optimicermod-client.toml");
    }
}
