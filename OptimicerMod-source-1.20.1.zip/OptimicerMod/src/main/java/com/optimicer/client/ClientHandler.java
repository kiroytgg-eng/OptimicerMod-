package com.optimicer.client;

import com.optimicer.OptimicerConfig;
import com.optimicer.OptimicerMod;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Objects;
import java.util.concurrent.locks.LockSupport;

/**
 * Logica de cliente:
 *  1) Desbloquea el limite de FPS y VSync al iniciar.
 *  2) Limitador propio opcional (admite > 260 FPS) y limite en segundo plano.
 *  3) Controlador dinamico: mide los FPS y sube/baja un "nivel de optimizacion".
 *     Al salir del mundo restaura los ajustes originales del jugador.
 */
@Mod.EventBusSubscriber(modid = OptimicerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientHandler {

    private static final long NANOS = 1_000_000_000L;

    // --- medicion de FPS / limitador ---
    private static long windowStart = System.nanoTime();
    private static long lastFrameEnd = System.nanoTime();
    private static int frames = 0;
    private static volatile int measuredFps = 0;
    private static volatile boolean newSample = false;

    // --- controlador ---
    private static boolean startupDone = false;
    private static boolean captured = false;
    private static int level = 0;
    private static int below = 0;
    private static int above = 0;
    private static int warmupTicks = 0;
    private static int cooldownTicks = 0;

    // --- ajustes originales del jugador ---
    private static int origRender = 12;
    private static ParticleStatus origParticles = ParticleStatus.ALL;
    private static double origEntity = 1.0D;
    private static boolean origShadows = true;
    private static CloudStatus origClouds = CloudStatus.FANCY;
    private static GraphicsStatus origGraphics = GraphicsStatus.FANCY;

    private ClientHandler() {}

    private static boolean isExtreme() {
        return OptimicerConfig.MODE.get() == OptimicerConfig.Mode.EXTREME;
    }

    // ------------------------------------------------------------------
    // Render: limitador + contador de FPS
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !OptimicerConfig.ENABLED.get()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();

        int cap = OptimicerConfig.FPS_CAP.get();
        if (OptimicerConfig.BACKGROUND_LIMIT.get() && !mc.isWindowActive()) {
            int bg = OptimicerConfig.BACKGROUND_FPS.get();
            cap = cap > 0 ? Math.min(cap, bg) : bg;
        }

        long now = System.nanoTime();
        if (cap > 0) {
            long target = lastFrameEnd + NANOS / cap;
            while ((now = System.nanoTime()) < target) {
                long remain = target - now;
                if (remain > 2_000_000L) {
                    LockSupport.parkNanos(remain - 1_000_000L);
                } else {
                    Thread.onSpinWait();
                }
            }
        }
        lastFrameEnd = now;

        frames++;
        long elapsed = now - windowStart;
        if (elapsed >= NANOS) {
            measuredFps = (int) (frames * NANOS / elapsed);
            frames = 0;
            windowStart = now;
            newSample = true;
        }
    }

    // ------------------------------------------------------------------
    // Tick: controlador dinamico
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Options o = mc.options;
        if (o == null) {
            return;
        }

        if (!OptimicerConfig.ENABLED.get()) {
            restore(o);
            return;
        }

        if (!startupDone) {
            startupDone = true;
            if (OptimicerConfig.UNLOCK_FPS.get()) {
                set(o.framerateLimit(), 260); // 260 = "Ilimitado"
            }
            if (OptimicerConfig.DISABLE_VSYNC.get()) {
                set(o.enableVsync(), false);
            }
            OptimicerMod.LOGGER.info("[OptimicerMod] Iniciado. Modo={}, objetivo={} FPS",
                    OptimicerConfig.MODE.get(), OptimicerConfig.TARGET_FPS.get());
        }

        // Fuera de un mundo: restaurar y reiniciar estado
        if (mc.level == null || mc.player == null) {
            restore(o);
            warmupTicks = 0;
            below = 0;
            above = 0;
            cooldownTicks = 0;
            newSample = false;
            return;
        }

        if (!OptimicerConfig.DYNAMIC_QUALITY.get()) {
            restore(o);
            return;
        }

        if (level == 0) {
            capture(o); // mientras no toquemos nada, recordamos tus ajustes actuales
        }

        warmupTicks++;
        if (cooldownTicks > 0) {
            cooldownTicks--;
        }

        boolean ext = isExtreme();
        int minLevel = ext ? 2 : 0;
        int maxLevel = ext ? 6 : 4;

        if (level < minLevel) {
            setLevel(mc, minLevel);
        } else if (level > maxLevel) {
            setLevel(mc, maxLevel);
        }

        if (!newSample) {
            return;
        }
        newSample = false;

        // Ignorar los primeros ~12 s tras entrar al mundo (carga de chunks), menus y ventana inactiva
        if (warmupTicks < 240 || cooldownTicks > 0 || mc.screen != null || !mc.isWindowActive()) {
            below = 0;
            above = 0;
            return;
        }

        int fps = measuredFps;
        int target = OptimicerConfig.TARGET_FPS.get();
        int cap = OptimicerConfig.FPS_CAP.get();
        if (cap > 0) {
            target = Math.min(target, cap);
        }

        if (fps < target * 0.85D) {
            below++;
            above = 0;
        } else if (fps > target * 1.30D) {
            above++;
            below = 0;
        } else {
            below = 0;
            above = 0;
        }

        if (below >= 3 && level < maxLevel) {
            setLevel(mc, level + 1);
            below = 0;
            cooldownTicks = 20 * 5;
        } else if (above >= 10 && level > minLevel) {
            setLevel(mc, level - 1);
            above = 0;
            cooldownTicks = 20 * 5;
        }
    }

    // ------------------------------------------------------------------
    // Niveles de optimizacion
    // ------------------------------------------------------------------
    private static void capture(Options o) {
        origRender = o.renderDistance().get();
        origParticles = o.particles().get();
        origEntity = o.entityDistanceScaling().get();
        origShadows = o.entityShadows().get();
        origClouds = o.cloudStatus().get();
        origGraphics = o.graphicsMode().get();
        captured = true;
    }

    private static void setLevel(Minecraft mc, int newLevel) {
        if (!captured) {
            capture(mc.options);
        }
        level = newLevel;
        applyLevel(mc.options, newLevel);
        if (OptimicerConfig.SHOW_MESSAGES.get() && mc.player != null) {
            mc.player.displayClientMessage(
                    Component.literal("[OptimicerMod] Nivel de optimizacion: " + newLevel), true);
        }
    }

    /**
     * Nivel 0 = tus ajustes originales.
     *  >=1 : baja la distancia de renderizado (2 chunks por nivel, con un minimo configurable)
     *  >=2 : particulas reducidas
     *  >=3 : menos distancia de entidades y sin sombras de entidades
     *  >=4 (AUTO) / >=3 (EXTREME): particulas minimas
     *  >=5 (solo EXTREME): sin nubes y graficos en modo Rapido
     */
    private static void applyLevel(Options o, int l) {
        boolean ext = isExtreme();

        int floor = ext ? OptimicerConfig.MIN_RENDER_DISTANCE_EXTREME.get()
                        : OptimicerConfig.MIN_RENDER_DISTANCE.get();
        int rd = origRender;
        if (l > 0) {
            rd = Math.min(origRender, Math.max(floor, origRender - 2 * l));
        }
        set(o.renderDistance(), rd);

        ParticleStatus p = origParticles;
        int minimalAt = ext ? 3 : 4;
        if (l >= minimalAt) {
            p = ParticleStatus.MINIMAL;
        } else if (l >= 2 && origParticles == ParticleStatus.ALL) {
            p = ParticleStatus.DECREASED;
        }
        set(o.particles(), p);

        double ent = origEntity;
        boolean shadows = origShadows;
        if (l >= 3) {
            ent = Math.min(origEntity, 0.75D);
            shadows = false;
        }
        set(o.entityDistanceScaling(), ent);
        set(o.entityShadows(), shadows);

        CloudStatus clouds = origClouds;
        GraphicsStatus gfx = origGraphics;
        if (ext && l >= 5) {
            clouds = CloudStatus.OFF;
            gfx = GraphicsStatus.FAST;
        }
        set(o.cloudStatus(), clouds);
        set(o.graphicsMode(), gfx);
    }

    private static void restore(Options o) {
        if (captured && level != 0) {
            level = 0;
            applyLevel(o, 0);
        }
        below = 0;
        above = 0;
    }

    private static <T> void set(OptionInstance<T> option, T value) {
        if (!Objects.equals(option.get(), value)) {
            option.set(value);
        }
    }
}
