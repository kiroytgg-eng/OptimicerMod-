package com.optimicer;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configuracion: se genera en config/optimicermod-client.toml */
public final class OptimicerConfig {

    public enum Mode { AUTO, EXTREME }

    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.EnumValue<Mode> MODE;
    public static final ForgeConfigSpec.IntValue TARGET_FPS;
    public static final ForgeConfigSpec.BooleanValue UNLOCK_FPS;
    public static final ForgeConfigSpec.BooleanValue DISABLE_VSYNC;
    public static final ForgeConfigSpec.IntValue FPS_CAP;
    public static final ForgeConfigSpec.BooleanValue DYNAMIC_QUALITY;
    public static final ForgeConfigSpec.IntValue MIN_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue MIN_RENDER_DISTANCE_EXTREME;
    public static final ForgeConfigSpec.BooleanValue BACKGROUND_LIMIT;
    public static final ForgeConfigSpec.IntValue BACKGROUND_FPS;
    public static final ForgeConfigSpec.BooleanValue SHOW_MESSAGES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("OptimicerMod - configuracion general").push("general");

        ENABLED = b.comment("Activa o desactiva todo el mod.")
                .define("enabled", true);

        MODE = b.comment(
                        "AUTO    = recomendado. Funciona sin configurar (objetivo por defecto: 400 FPS).",
                        "EXTREME = recorta bastante mas la calidad visual para buscar el maximo FPS",
                        "          (pensado para targetFps = 699).")
                .defineEnum("mode", Mode.AUTO);

        TARGET_FPS = b.comment(
                        "FPS que quieres alcanzar. El mod baja la calidad poco a poco hasta acercarse a esta cifra",
                        "y la vuelve a subir si te sobra rendimiento. Es un OBJETIVO, no una garantia:",
                        "lo que alcances depende de tu PC.")
                .defineInRange("targetFps", 400, 30, 2000);

        UNLOCK_FPS = b.comment("Quita el limite de FPS de Minecraft (pone 'Ilimitado') al iniciar el juego.")
                .define("unlockFps", true);

        DISABLE_VSYNC = b.comment("Desactiva VSync al iniciar el juego (mas FPS, puede haber tearing).")
                .define("disableVsync", true);

        FPS_CAP = b.comment("Limite propio de FPS (admite mas de 260). 0 = sin limite.")
                .defineInRange("fpsCap", 0, 0, 5000);

        b.pop();

        b.comment("Calidad dinamica").push("dynamic");

        DYNAMIC_QUALITY = b.comment("Ajusta automaticamente distancia de renderizado, particulas, etc. segun tus FPS.",
                        "Al salir del mundo se restauran tus ajustes originales.")
                .define("dynamicQuality", true);

        MIN_RENDER_DISTANCE = b.comment("Distancia de renderizado minima a la que puede bajar en modo AUTO.")
                .defineInRange("minRenderDistance", 8, 2, 32);

        MIN_RENDER_DISTANCE_EXTREME = b.comment("Distancia de renderizado minima en modo EXTREME.")
                .defineInRange("minRenderDistanceExtreme", 4, 2, 32);

        SHOW_MESSAGES = b.comment("Muestra un aviso en la barra de acciones cuando cambia el nivel de optimizacion.")
                .define("showMessages", false);

        b.pop();

        b.comment("Ventana en segundo plano").push("background");

        BACKGROUND_LIMIT = b.comment("Limita los FPS cuando la ventana del juego no esta en primer plano.")
                .define("backgroundLimit", true);

        BACKGROUND_FPS = b.comment("FPS maximos con la ventana en segundo plano.")
                .defineInRange("backgroundFps", 30, 1, 260);

        b.pop();

        SPEC = b.build();
    }

    private OptimicerConfig() {}
}
